Recovered from the accepted draft immediately before formatting.
The included PDF and TeX are the original pre-formatting artifacts, with 42 references.
The draft retains its original layout and unresolved length feedback.
Compile from this directory with pdfLaTeX, BibTeX, then pdfLaTeX twice.
The files in figure_code contain the exact R/ggplot2 and TikZ sources used for the figures.
