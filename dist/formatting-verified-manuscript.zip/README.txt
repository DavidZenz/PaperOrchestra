Exact manuscript from the final formatting-scope validation run.
The 35-reference list appears on pages 8-10.
Compile with pdfLaTeX, BibTeX, then pdfLaTeX twice in this directory.
The figure_code files are the exact R/ggplot2 and TikZ sources used in the manuscript.
This workflow demonstration still has layout and length issues as reported in its validation.
