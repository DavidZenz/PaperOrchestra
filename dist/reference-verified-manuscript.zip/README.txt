Exact generated manuscript/source project. References are on PDF pages5–6.
Compile from this directory: pdflatex final_paper.tex; bibtex final_paper; pdflatex final_paper.tex; pdflatex final_paper.tex.
The figure_code paths are the exact worker-generated sources used by the manuscript. R worker.R is the retained export wrapper; TikZ source.tex is standalone. No alternative figure recipes are included.
The full run and provider/citation evidence are under validation/reference-fix-e2e-complete in the repository.
The upstream formatting pass shortened the manuscript/reference list (42 initial citations,18 final); there is no post-format peer ensemble. Layout remains an upstream workflow output, including a duplicated figure-source discussion/appendix.
