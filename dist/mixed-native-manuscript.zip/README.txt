Synthetic four-runtime PaperOrchestra workflow demonstration.
The source appendix identifies the exact R/ggplot2 and TikZ files used.
R: run Rscript --vanilla worker.R inside figure_code/fig_intercept_error/.
TikZ: run pdflatex -no-shell-escape -interaction=nonstopmode -halt-on-error source.tex inside figure_code/fig_residual_workflow/.
These invoke the actual selected sources; no replacement recipe is supplied.
Compile final_paper.tex in this directory (standard article/TeX dependencies).
Full trace, original candidates, native events, replay utility and software metadata:
https://github.com/DavidZenz/PaperOrchestra/tree/main/validation/multiruntime-e2e-final
All five successful figure attempts replayed identical previews in the recorded environment.
Different software/fonts can change output; new LLM runs are stochastic.
Known visual limit: Figure1 evaluation-box text overlaps its nearby annotation.
It is retained exactly as selected by the upstream bounded figure/refinement workflow.
