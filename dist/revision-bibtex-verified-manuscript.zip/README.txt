Manuscript from the live BibTeX revision validation.
The second accepted content revision is the source, with three float placement edits.
Compile with pdfLaTeX, BibTeX, and pdfLaTeX twice.
The figure_code directory contains the exact R/ggplot2 and TikZ sources.
